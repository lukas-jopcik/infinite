const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, UpdateCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'eu-central-1' });
const dynamodb = DynamoDBDocumentClient.from(client);

// CORS headers for API Gateway
const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
};

exports.handler = async (event) => {
    console.log('Analytics API Lambda invoked:', JSON.stringify(event, null, 2));
    
    // Handle CORS preflight
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({ message: 'CORS preflight' })
        };
    }
    
    const { httpMethod, path, pathParameters, body, queryStringParameters } = event;
    
    try {
        switch (httpMethod) {
            case 'POST':
                if (path === '/analytics/view') {
                    return await trackView(body);
                } else if (path === '/analytics/engagement') {
                    return await trackEngagement(body);
                }
                break;
                
            case 'GET':
                if (path === '/analytics/stats') {
                    return await getAnalyticsStats(queryStringParameters);
                }
                break;
                
            default:
                return createResponse(405, { error: 'Method not allowed' });
        }
        
        return createResponse(404, { error: 'Endpoint not found' });
        
    } catch (error) {
        console.error('Analytics API Error:', error);
        return createResponse(500, { 
            error: 'Internal server error',
            message: error.message 
        });
    }
};

// Track article view
async function trackView(body) {
    try {
        const data = JSON.parse(body);
        const { articleId, userId, userAgent, referrer, timestamp } = data;
        
        // Validate required fields
        if (!articleId) {
            return createResponse(400, { error: 'articleId is required' });
        }
        
        const viewId = `view_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const viewTimestamp = timestamp || new Date().toISOString();
        
        // Store view data
        const viewData = {
            viewId,
            articleId,
            userId: userId || 'anonymous',
            userAgent: userAgent || 'unknown',
            referrer: referrer || 'direct',
            timestamp: viewTimestamp,
            date: viewTimestamp.split('T')[0], // YYYY-MM-DD format
            hour: new Date(viewTimestamp).getHours(),
            type: 'view'
        };
        
        await dynamodb.send(new PutCommand({
            TableName: 'InfiniteAnalytics-dev',
            Item: viewData
        }));
        
        // Update article view count
        await updateArticleViewCount(articleId);
        
        console.log('View tracked successfully:', viewId);
        
        return createResponse(200, {
            success: true,
            viewId,
            message: 'View tracked successfully'
        });
        
    } catch (error) {
        console.error('Error tracking view:', error);
        return createResponse(500, { error: 'Failed to track view' });
    }
}

// Track user engagement
async function trackEngagement(body) {
    try {
        const data = JSON.parse(body);
        const { articleId, userId, engagementType, value, metadata } = data;
        
        // Validate required fields
        if (!articleId || !engagementType) {
            return createResponse(400, { error: 'articleId and engagementType are required' });
        }
        
        const engagementId = `eng_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const timestamp = new Date().toISOString();
        
        // Store engagement data
        const engagementData = {
            engagementId,
            articleId,
            userId: userId || 'anonymous',
            engagementType, // 'scroll', 'click', 'share', 'time_spent', etc.
            value: value || 0,
            metadata: metadata || {},
            timestamp,
            date: timestamp.split('T')[0],
            hour: new Date(timestamp).getHours(),
            type: 'engagement'
        };
        
        await dynamodb.send(new PutCommand({
            TableName: 'InfiniteAnalytics-dev',
            Item: engagementData
        }));
        
        console.log('Engagement tracked successfully:', engagementId);
        
        return createResponse(200, {
            success: true,
            engagementId,
            message: 'Engagement tracked successfully'
        });
        
    } catch (error) {
        console.error('Error tracking engagement:', error);
        return createResponse(500, { error: 'Failed to track engagement' });
    }
}

// Get analytics statistics
async function getAnalyticsStats(queryParams) {
    try {
        const { 
            startDate, 
            endDate, 
            articleId, 
            engagementType,
            limit = 100 
        } = queryParams || {};
        
        // Build filter expression
        let filterExpression = '';
        let expressionAttributeValues = {};
        let expressionAttributeNames = {};
        
        if (startDate) {
            filterExpression += ' AND #date >= :startDate';
            expressionAttributeNames['#date'] = 'date';
            expressionAttributeValues[':startDate'] = startDate;
        }
        
        if (endDate) {
            filterExpression += ' AND #date <= :endDate';
            expressionAttributeNames['#date'] = 'date';
            expressionAttributeValues[':endDate'] = endDate;
        }
        
        if (articleId) {
            filterExpression += ' AND articleId = :articleId';
            expressionAttributeValues[':articleId'] = articleId;
        }
        
        if (engagementType) {
            filterExpression += ' AND engagementType = :engagementType';
            expressionAttributeValues[':engagementType'] = engagementType;
        }
        
        // Remove leading AND
        if (filterExpression) {
            filterExpression = filterExpression.substring(5);
        }
        
        const scanParams = {
            TableName: 'InfiniteAnalytics-dev',
            Limit: parseInt(limit)
        };
        
        if (filterExpression) {
            scanParams.FilterExpression = filterExpression;
            scanParams.ExpressionAttributeValues = expressionAttributeValues;
            scanParams.ExpressionAttributeNames = expressionAttributeNames;
        }
        
        const result = await dynamodb.send(new ScanCommand(scanParams));
        
        // Process and aggregate data
        const analytics = processAnalyticsData(result.Items);
        
        return createResponse(200, {
            success: true,
            data: analytics,
            totalItems: result.Items.length,
            query: {
                startDate,
                endDate,
                articleId,
                engagementType,
                limit
            }
        });
        
    } catch (error) {
        console.error('Error getting analytics stats:', error);
        return createResponse(500, { error: 'Failed to get analytics stats' });
    }
}

// Process and aggregate analytics data
function processAnalyticsData(items) {
    const analytics = {
        totalViews: 0,
        totalEngagements: 0,
        viewsByDate: {},
        viewsByHour: {},
        engagementTypes: {},
        topArticles: {},
        userEngagement: {}
    };
    
    items.forEach(item => {
        if (item.type === 'view') {
            analytics.totalViews++;
            
            // Views by date
            if (!analytics.viewsByDate[item.date]) {
                analytics.viewsByDate[item.date] = 0;
            }
            analytics.viewsByDate[item.date]++;
            
            // Views by hour
            if (!analytics.viewsByHour[item.hour]) {
                analytics.viewsByHour[item.hour] = 0;
            }
            analytics.viewsByHour[item.hour]++;
            
            // Top articles
            if (!analytics.topArticles[item.articleId]) {
                analytics.topArticles[item.articleId] = 0;
            }
            analytics.topArticles[item.articleId]++;
            
        } else if (item.type === 'engagement') {
            analytics.totalEngagements++;
            
            // Engagement types
            if (!analytics.engagementTypes[item.engagementType]) {
                analytics.engagementTypes[item.engagementType] = 0;
            }
            analytics.engagementTypes[item.engagementType]++;
            
            // User engagement
            if (!analytics.userEngagement[item.userId]) {
                analytics.userEngagement[item.userId] = 0;
            }
            analytics.userEngagement[item.userId]++;
        }
    });
    
    // Sort top articles
    analytics.topArticles = Object.entries(analytics.topArticles)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 10)
        .reduce((obj, [key, value]) => {
            obj[key] = value;
            return obj;
        }, {});
    
    return analytics;
}

// Update article view count
async function updateArticleViewCount(articleId) {
    try {
        await dynamodb.send(new UpdateCommand({
            TableName: 'InfiniteArticles-dev',
            Key: {
                articleId: articleId,
                type: 'discovery'
            },
            UpdateExpression: 'ADD viewCount :increment',
            ExpressionAttributeValues: {
                ':increment': 1
            }
        }));
        
        console.log('Article view count updated:', articleId);
    } catch (error) {
        console.error('Error updating article view count:', error);
        // Don't throw error as this is not critical
    }
}

// Helper function to create HTTP response
function createResponse(statusCode, body) {
    return {
        statusCode,
        headers: corsHeaders,
        body: JSON.stringify(body)
    };
}
